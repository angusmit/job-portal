package com.example.jobportal.model;

public enum ScrapingFrequency {
    HOURLY, DAILY, WEEKLY, MONTHLY
}