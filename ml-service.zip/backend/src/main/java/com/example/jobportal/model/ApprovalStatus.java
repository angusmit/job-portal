package com.example.jobportal.model;

public enum ApprovalStatus {
    PENDING, APPROVED, REJECTED
}