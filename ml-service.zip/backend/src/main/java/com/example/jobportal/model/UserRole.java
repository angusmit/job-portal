package com.example.jobportal.model;

public enum UserRole {
    JOB_SEEKER, EMPLOYER, ADMIN
}