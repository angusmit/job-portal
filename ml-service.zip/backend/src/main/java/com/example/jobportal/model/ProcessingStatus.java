package com.example.jobportal.model;

public enum ProcessingStatus {
    PENDING, PROCESSING, COMPLETED, FAILED, EXPIRED
}