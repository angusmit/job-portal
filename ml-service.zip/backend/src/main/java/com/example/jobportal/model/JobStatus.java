package com.example.jobportal.model;

public enum JobStatus {
    PENDING, APPROVED, REJECTED
}